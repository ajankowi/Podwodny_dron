#ifndef ROZMIAR_H
#define ROZMIAR_H

#define ROZMIAR   5

#endif
