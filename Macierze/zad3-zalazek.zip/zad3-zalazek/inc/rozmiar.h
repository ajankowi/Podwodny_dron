#ifndef ROZMIAR_H
#define ROZMIAR_H

#define ROZMIAR   3

#endif
