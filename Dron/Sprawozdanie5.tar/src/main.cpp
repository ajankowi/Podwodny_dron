#include <iostream>
#include <iomanip>
#include "lacze_do_gnuplota.hh"
#include "SWektor.hh"
#include "Lamana.hh"
#include "PowierzchniaGeom.hh"
#include "PowierzchniaGeomScn.hh"
#include "Scena.hh"
#include "Dron.hh"

using namespace std;


int main(){
 
    Scena S;
    S.Start();
/*
  PzG::LaczeDoGNUPlota  Lacze;
  char c;


  Lacze.DodajNazwePliku("bryly/date.dat");
  
  Lacze.ZmienTrybRys(PzG::TR_3D);
  Lacze.Inicjalizuj();  // Tutaj startuje gnuplot.

  Lacze.UstawZakresX(-6, 6);
  Lacze.UstawZakresY(-8, 8);
  Lacze.UstawZakresZ(-5, 5);


  Lacze.UstawRotacjeXZ(40,60); // Tutaj ustawiany jest widok

  Lacze.Rysuj();        // Teraz powinno pojawic sie okienko gnuplota
                        // z rysunkiem, o ile istnieje plik "prostopadloscian1.dat"
  cout << "Nacisnij ENTER, aby zobaczyc prostopadloscian nr 2 ... " << flush;
  cin >> noskipws >> c;

  Lacze.UsunWszystkieNazwyPlikow();
  Lacze.DodajNazwePliku("bryly/prostopadloscian2.dat");
  Lacze.Rysuj();        // Teraz powinno pojawic sie okienko gnuplota
                        // z rysunkiem, o ile istnieje plik "prostopadloscian2.dat"

  cout << "Nacisnij ENTER, aby zobaczyc prostopadloscian nr 3 ... " << flush;
  cin >> noskipws >> c;

  Lacze.UsunWszystkieNazwyPlikow();
  Lacze.DodajNazwePliku("bryly/prostopadloscian3.dat");
  Lacze.Rysuj();        // Teraz powinno pojawic sie okienko gnuplota
                        // z rysunkiem, o ile istnieje plik "prostopadloscian3.dat"

  cout << "Nacisnij ENTER, aby zakonczyc ... " << flush;
  cin >> noskipws >> c;
*/

}

