#ifndef POWIERZCHNIADNA_HH
#define POWIERZCHNIADNA_HH

#include "PowierzchniaGeomScn.hh"

class PowierzchniaDna : public PowierzchniaGeomScn{

    public:
        
        //Metdoa inicjuje Dno
        void InicjujDno();

        //Metoda umozliwia zapisanieDna
        void ZapiszDno();


};






































#endif
