#ifndef POWIERZCHNIAWODY_HH
#define POWIERZCHNIAWODY_HH

#include "PowierzchniaGeomScn.hh"

class PowierzchniaWody : public PowierzchniaGeomScn{

    public:
    
        //Metdoa inicjuje powierzchnie wody
        void InicjujWode();

        //Metoda umozliwia zapisanie powierzchni dna do pliku
        void ZapiszWode();

};





































#endif
