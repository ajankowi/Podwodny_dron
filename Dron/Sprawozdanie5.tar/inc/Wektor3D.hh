#ifndef WEKTOR3D_HH
#define WEKTOR3D_HH

#include "SWektor.hh"

//Wektor3D umożliwia zapisanie współrzędnych wekora w przestrzeni


typedef SWektor<double ,3>  Wektor3D;

#endif
